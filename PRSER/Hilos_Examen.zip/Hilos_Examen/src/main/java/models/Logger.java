package models;

public class Logger {

}
