package hlc.ud04.appsec.seguridad.controlacceso;

public enum Operacion {
  LECTURA,
  ESCRITURA
}
