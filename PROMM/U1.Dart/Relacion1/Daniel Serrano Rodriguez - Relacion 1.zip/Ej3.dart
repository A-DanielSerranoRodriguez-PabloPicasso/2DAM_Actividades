void main(List<String> args) {
  String tara = "tara";
  int num = 23;
  print(tara + "$num");
}
