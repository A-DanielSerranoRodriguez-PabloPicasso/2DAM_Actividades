package utils;

public interface BloqueDatos {

  public boolean contieneDato(String nombre);
  
  public String getDato(String nombre);
  
}
