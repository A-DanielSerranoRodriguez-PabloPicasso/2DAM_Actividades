package hibernate.persistence.interfaces;

import models.Vehiculo;

public interface VehiculoDaoI extends CommonDaoI<Vehiculo>{

	
}
