package mainApp;

import utils.Binario;
import utils.CSV;

public class MainApp {

	public static void main(String[] args) {
		String csv = "src/main/resources/Empleados.csv";
		String dat = "src/main/resources/NoPetesPls.dat";
//		CSV.ordenar_Archivo_CSV(csv);
//		CSV.fichero_CSV_to_Binario(csv);
//		Binario.fichero_Binario_to_CSV(dat);
		Binario.fichero_Binario_to_CSV_ordenado(dat);
//		MainWindow ventana = new MainWindow();
	}

}
