package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.ArrayList;

import models.Categorias;
import models.Productos;
import models.Proveedores;

public class NeptunoDAO extends AbstractDAO {
	private Savepoint sp;

	/**
	 * Constructor para conectarse a la base de datos bd_neptuno
	 * 
	 * @throws SQLException
	 */
	public NeptunoDAO() throws SQLException {
		super();
		getStatement().execute("use bd_neptuno");
	}

	/**
	 * Activa las transacciones
	 * 
	 * @throws SQLException
	 */
	public void disableAutocommit() throws SQLException {
		CONN.setAutoCommit(false);
	}

	/**
	 * Desactiva las transacciones
	 * 
	 * @throws SQLException
	 */
	public void enableAutocommit() throws SQLException {
		CONN.setAutoCommit(true);
	}

	/**
	 * Crea un Savepoint al que volver en un rollback
	 * 
	 * @param sp String con el nombre del Savepoint
	 * @throws SQLException
	 */
	public void setSavepoint() throws SQLException {
		sp = CONN.setSavepoint("no_commits");
	}

	/**
	 * Hace un rollback de la transaccion
	 * 
	 * @param sp Savepoint al que volver
	 * @throws SQLException
	 */
	public void rollback(Savepoint sp) throws SQLException {
		CONN.rollback(sp);
	}

	/**
	 * Hace un commit de la transaccion
	 * 
	 * @throws SQLException
	 */
	public void commit() throws SQLException {
		CONN.commit();
	}

	/**
	 * Obtiene las categorias
	 * 
	 * @param idCat Id de las categorias que obtener
	 * @return ResultSet
	 * @throws SQLException
	 */
	public ResultSet getCategorias(int idCat) throws SQLException {
		String sql = "select * from categorias where id = ?;";
		PreparedStatement prepStmt = getPreparedStatement(sql);

		prepStmt.setInt(1, idCat);

		return prepStmt.executeQuery();
	}

	/**
	 * Obtiene los productos
	 * 
	 * @param idCat Id de categoria por la que buscar el producto
	 * @return ResultSet
	 * @throws SQLException
	 */
	public ResultSet getProductos(int idCat) throws SQLException {
		String sql = "select * from productos where categoria_id = ?;";
		PreparedStatement prepStmt = getPreparedStatement(sql);

		prepStmt.setInt(1, idCat);

		return prepStmt.executeQuery();
	}

	/**
	 * Obtiene los proveedores
	 * 
	 * @param idProvs Id de los proveedores que buscar
	 * @return ResultSet
	 * @throws SQLException
	 */
	public ResultSet getProveedores(ArrayList<Integer> idProvs) throws SQLException {
		String sql = "select * from proveedores where id = ?";

		for (int i = 0; i < idProvs.size() - 1; i++)
			sql += " or id = ?";
		sql += ";";

		PreparedStatement prepStmt = getPreparedStatement(sql);

		for (int i = 0; i < idProvs.size(); i++)
			prepStmt.setInt(i + 1, idProvs.get(i));

		return prepStmt.executeQuery();
	}

	/**
	 * Inserta categorias en Categorias_new
	 * 
	 * @param cat      Categoria a insertar
	 * @param numLinea int
	 * @throws SQLException
	 */
	public int insertNewCategoria(Categorias cat, int numLinea) {
		String sql = "insert into Categorias_new values(?,?,?);";
		PreparedStatement prepStmt;
		try {
			prepStmt = getPreparedStatement(sql);
			prepStmt.setInt(1, cat.getId());
			prepStmt.setString(2, cat.getCategoria());
			prepStmt.setString(3, cat.getDescripcion());

			prepStmt.execute();
		} catch (SQLException e) {
			System.out.println("Error de insercion de datos, linea: " + numLinea);
			try {
				CONN.rollback(sp);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				CONN.commit();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return numLinea;
	}

	/**
	 * Inserta proveedores en Proveedores_new
	 * 
	 * @param proveedores ArrayList<Proveedores>
	 * @param numLinea    int
	 * @throws SQLException
	 */
	public int insertNewProovedores(ArrayList<Proveedores> proveedores, int numLinea) {
		String sql = "insert into Proveedores_new values(?,?,?);";
		PreparedStatement prepStmt;
		try {
			prepStmt = getPreparedStatement(sql);
			for (Proveedores prov : proveedores) {
				numLinea++;
				prepStmt.setInt(1, prov.getId());
				prepStmt.setString(2, prov.getEmpresa());
				prepStmt.setString(3, prov.getContacto());
				prepStmt.execute();
			}
		} catch (SQLException e) {
			System.out.println("Error de insercion de datos, linea: " + numLinea);
			try {
				CONN.rollback(sp);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				CONN.commit();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return numLinea;
	}

	/**
	 * Inserta productos en Productos_new
	 * 
	 * @param productos ArrayList<Productos>
	 * @param numLinea  int
	 * @throws SQLException
	 */
	public int insertNewProductos(ArrayList<Productos> productos, int numLinea) {
		String sql = "insert into Productos_new values(?,?,?,?,?,?,?,?,?,?);";
		PreparedStatement prepStmt;
		try {
			prepStmt = getPreparedStatement(sql);
			for (Productos prod : productos) {
				numLinea++;
				prepStmt.setInt(1, prod.getId());
				prepStmt.setString(2, prod.getProducto());
				prepStmt.setInt(3, prod.getProveedorId());
				prepStmt.setInt(4, prod.getCategoriaId());
				prepStmt.setString(5, prod.getCantidadPorUnidad());
				prepStmt.setDouble(6, prod.getPrecioUnidad());
				prepStmt.setInt(7, prod.getUnidadesExistencia());
				prepStmt.setInt(8, prod.getUnidadesPedido());
				prepStmt.setInt(9, prod.getNivelNuevoPedido());
				prepStmt.setInt(10, prod.getSuspendido());
				prepStmt.execute();
			}
		} catch (SQLException e) {
			System.out.println("Error de insercion de datos, linea: " + numLinea);
			try {
				CONN.rollback(sp);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				CONN.commit();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return numLinea;
	}
}
