package hlc.ud04.appsec.sampleapp.hotp.auth.otp;

public class GeneradorException extends RuntimeException {

  public GeneradorException(String message, Throwable cause) {
    super(message, cause);
  }

}
