package hibernate.services.interfaces;

import models.Vehiculo;

public interface VehiculoManagmentServiceI {
	public void insertNewVehiculo(final Vehiculo newVehiculo);
	
}
