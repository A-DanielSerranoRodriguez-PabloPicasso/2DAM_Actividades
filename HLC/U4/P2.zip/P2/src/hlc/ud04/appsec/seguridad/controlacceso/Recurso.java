package hlc.ud04.appsec.seguridad.controlacceso;

public interface Recurso {

}
