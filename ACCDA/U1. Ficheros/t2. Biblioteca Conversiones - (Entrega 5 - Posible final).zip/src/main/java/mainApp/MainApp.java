package mainApp;

import ui.MainWindow;

public class MainApp {

	public static void main(String[] args) {
		// Opens the main view
		@SuppressWarnings("unused")
		MainWindow ventana = new MainWindow();
	}
}
