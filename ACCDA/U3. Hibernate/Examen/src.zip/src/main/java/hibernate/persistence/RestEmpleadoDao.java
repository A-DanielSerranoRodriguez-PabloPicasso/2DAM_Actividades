package hibernate.persistence;

import hibernate.persistence.models.RestEmpleado;

public interface RestEmpleadoDao extends CommonDao<RestEmpleado> {

}
