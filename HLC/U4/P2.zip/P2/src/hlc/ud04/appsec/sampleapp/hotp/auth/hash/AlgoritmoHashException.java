package hlc.ud04.appsec.sampleapp.hotp.auth.hash;

public class AlgoritmoHashException extends RuntimeException {

  public AlgoritmoHashException(String message, Throwable cause) {
    super(message, cause);
  }

}
