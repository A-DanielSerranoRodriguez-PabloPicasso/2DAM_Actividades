package mainApp;

import ui.MainWindow;

public class MainApp {

	public static void main(String[] args) {
		MainWindow ventana = new MainWindow();
	}
}
