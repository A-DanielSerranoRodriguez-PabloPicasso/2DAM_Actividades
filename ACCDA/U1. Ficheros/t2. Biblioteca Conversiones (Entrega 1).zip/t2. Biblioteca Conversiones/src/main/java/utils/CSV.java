package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class CSV {
	public static boolean fichero_CSV_to_Binario(String fichero) {
		File csv = new File(fichero);

		if (csv.exists()) {
			String fName = csv.getName();
			int fLenght = csv.getName().length();

			if (fName.charAt(fLenght - 4) == '.') {
				String ofName = fName.substring(0, fLenght - 4), fExtension = fName.substring(fLenght - 3);

				if (fExtension.equals("csv")) {
					String linea;
					FileReader fr = null;
					FileOutputStream fos = null;
					ObjectOutputStream oos = null;
					try {
						try {
							fr = new FileReader(csv);
							fos = new FileOutputStream(csv.getAbsolutePath().replaceAll(fName, "") + ofName + ".dat");
							oos = new ObjectOutputStream(fos);
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
						BufferedReader br = new BufferedReader(fr);

						try {
							while ((linea = br.readLine()) != null) {
								oos.writeObject((String) linea);
							}
							oos.flush();
						} finally {
							oos.close();
							br.close();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}

					return true;
				} else
					return false;
			} else
				return false;
		} else
			return false;
	}

	public static boolean ordenar_Archivo_CSV(String fichero) {
		// TODO
		File csv = new File(fichero);

		if (csv.exists()) {
			String fName = csv.getName();
			int fLenght = csv.getName().length();

			if (fName.charAt(fLenght - 4) == '.') {
				String ofName = fName.substring(0, fLenght - 4), fExtension = fName.substring(fLenght - 3);

				if (fExtension.equals("csv")) {
					String linea;
					FileReader fr = null;
					FileOutputStream fos = null;
					ObjectOutputStream oos = null;
					try {
						try {
							fr = new FileReader(csv);
							fos = new FileOutputStream(csv.getAbsolutePath().replaceAll(fName, "") + ofName + ".dat");
							oos = new ObjectOutputStream(fos);
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
						BufferedReader br = new BufferedReader(fr);

						try {
							while ((linea = br.readLine()) != null) {
								oos.writeObject((String) linea);
							}
							oos.flush();
						} finally {
							oos.close();
							br.close();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}

					return true;
				} else
					return false;
			} else
				return false;
		} else
			return false;
	}

	public static boolean fichero_CSV_to_Binario_ordenado(File csv) {
		return false;
	}
}
