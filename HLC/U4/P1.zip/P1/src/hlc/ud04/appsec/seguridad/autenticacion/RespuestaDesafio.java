package hlc.ud04.appsec.seguridad.autenticacion;

/**
 * Respuesta a un desafío. Contiene la información que ha proporcionado el usuario
 * en respuesta a un desafío
 * @author mmontoro
 *
 */
public interface RespuestaDesafio {

}
