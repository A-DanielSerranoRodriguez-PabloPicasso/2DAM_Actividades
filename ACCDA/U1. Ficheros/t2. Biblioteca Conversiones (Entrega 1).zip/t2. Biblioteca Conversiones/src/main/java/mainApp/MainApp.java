package mainApp;

import java.util.ArrayList;

import utils.Binario;
import utils.CSV;

public class MainApp {

	public static void main(String[] args) {
		String arch = "src/main/resources/Empleados.csv";
		CSV.fichero_CSV_to_Binario(arch);
		Binario.fichero_Binario_to_CSV("src/main/resources/Empleados.dat");
		ArrayList<String> cacota = new ArrayList<>();
		cacota.add("e");
		cacota.add("a");
		cacota.sort((o1, o2) -> o1.compareTo(o2));
		
		for (String str : cacota) {
			System.out.println(str);
		}
//		MainWindow ventana = new MainWindow();
	}

}
