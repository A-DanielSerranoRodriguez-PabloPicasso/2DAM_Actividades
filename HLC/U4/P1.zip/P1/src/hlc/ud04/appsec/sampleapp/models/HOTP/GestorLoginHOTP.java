package hlc.ud04.appsec.sampleapp.models.HOTP;

public interface GestorLoginHOTP {
	public LoginHOTP getLogin(String usuario);
}
