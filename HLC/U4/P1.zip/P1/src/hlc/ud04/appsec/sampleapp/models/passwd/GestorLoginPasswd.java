package hlc.ud04.appsec.sampleapp.models.passwd;

public interface GestorLoginPasswd {
	public LoginPasswd getLogin(String secreto);
}
