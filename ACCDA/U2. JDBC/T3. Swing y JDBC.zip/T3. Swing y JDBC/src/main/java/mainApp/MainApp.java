package mainApp;

import ui.FilmViewer;

public class MainApp {

	public static void main(String[] args) {
		new FilmViewer();
	}
}
