package utils;

import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Binario {
	public static File fichero_Binario_to_CSV(String fichero) {
		File dat = new File(fichero), gen = null;

		if (dat.exists()) {
			String fName = dat.getName();
			int fLenght = dat.getName().length();

			if (fName.charAt(fLenght - 4) == '.') {
				String ofName = fName.substring(0, fLenght - 4), fExtension = fName.substring(fLenght - 3);

				if (fExtension.equals("dat")) {
					String linea, ofExtension = ".csv";
					FileWriter fw = null;
					FileInputStream fis = null;
					ObjectInputStream ois = null;
					try {
						try {
							gen = new File(dat.getAbsolutePath().replaceAll(fName, ofName + "_fromBin" + ofExtension));
							fw = new FileWriter(gen);
							fis = new FileInputStream(dat);
							ois = new ObjectInputStream(fis);
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
						BufferedWriter br = new BufferedWriter(fw);

						try {
							while ((linea = (String) ois.readObject()) != null) {
								br.write(linea);
							}
							br.flush();
						} catch (ClassNotFoundException e) {
							e.printStackTrace();
						} catch (EOFException e) {
						} finally {
							br.close();
							ois.close();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		return gen;
	}

	public static boolean ordenar_Archivo_Binario(String fichero) {
		return false;
	}

	public static boolean fichero_Binario_to_CSV_ordenado(String fichero) {
		return false;
	}
}
