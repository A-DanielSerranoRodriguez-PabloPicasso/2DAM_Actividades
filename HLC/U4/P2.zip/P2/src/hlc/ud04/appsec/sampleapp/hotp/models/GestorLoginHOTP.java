package hlc.ud04.appsec.sampleapp.hotp.models;

public interface GestorLoginHOTP {
	public LoginHOTP getLogin(String usuario);
}
