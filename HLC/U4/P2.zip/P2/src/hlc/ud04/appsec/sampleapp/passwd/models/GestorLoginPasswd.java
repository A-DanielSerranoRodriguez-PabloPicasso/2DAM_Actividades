package hlc.ud04.appsec.sampleapp.passwd.models;

public interface GestorLoginPasswd {
	public LoginPasswd getLogin(String secreto);
}
