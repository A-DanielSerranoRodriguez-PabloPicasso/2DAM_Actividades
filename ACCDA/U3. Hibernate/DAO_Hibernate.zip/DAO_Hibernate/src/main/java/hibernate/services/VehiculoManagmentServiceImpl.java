package hibernate.services;

public class VehiculoManagmentServiceImpl {

//	public class VehiculoManagmentServiceImp
}
