package hlc.ud04.appsec.sampleapp.passwd.models;

public interface GestorPasswdPermisos {
	public PasswdPermisos getUsuario(long l);
}
